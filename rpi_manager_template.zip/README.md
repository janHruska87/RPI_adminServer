# RPI Management API

REST API pro správu RPI jednotek, uživatelů a příjem souborů.